const bg = document.querySelector(".bg");
const shade = document.querySelector(".shade");
const text = document.querySelector(".text");

function updateParallax() {
  const scrollY = window.scrollY;
  const scale = 1 + scrollY * 0.00045;
  const opacity = Math.min(scrollY / 650, 1);
  const lift = Math.min(scrollY * 0.18, 120);

  bg.style.transform = `scale(${scale})`;
  shade.style.opacity = opacity.toFixed(3);
  text.style.transform = `translateY(-${lift}px)`;
}

let ticking = false;

function requestTick() {
  if (!ticking) {
    window.requestAnimationFrame(() => {
      updateParallax();
      ticking = false;
    });
    ticking = true;
  }
}

window.addEventListener("scroll", requestTick, { passive: true });
window.addEventListener("resize", requestTick);

updateParallax();