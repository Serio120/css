const bg = document.querySelector(".bg");
const textPanel = document.querySelector(".text-panel");

function updateParallax() {
  const scrollY = window.scrollY;
  const scale = 1 + scrollY * 0.00045;
  const lift = Math.min(scrollY * 0.16, 110);

  bg.style.transform = `scale(${scale})`;
  textPanel.style.transform = `translateY(-${lift}px)`;
}

let ticking = false;

function requestTick() {
  if (!ticking) {
    window.requestAnimationFrame(() => {
      updateParallax();
      ticking = false;
    });
    ticking = true;
  }
}

window.addEventListener("scroll", requestTick, { passive: true });
window.addEventListener("resize", requestTick);

updateParallax();